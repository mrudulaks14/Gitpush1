package com.test.jbehave.steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.jbehave.utils.DriverDefinitions;
import com.test.jbehave.utils.ReusableMethods;

public class AmzonLogin {

	WebDriver driver = null;
	WebDriverWait oWait = null;
	ReusableMethods reUse = null;

	public AmzonLogin() throws Throwable {
		try {
			driver = DriverDefinitions.getDriver();
			reUse = new ReusableMethods();
		} catch (Exception e) {
			throw e;
		}
	}

	@Given("User provided with Amazon login url")
	public void givenUserProvidedWithAmazonLoginUrl() throws Throwable {
		try {
			String url = reUse.getProperty("amazonURL");
			driver.get(url);
			reUse.assertTitleContains("amazonPageTitle");
			reUse.click("AmazonLoginbtn");
		} catch (Exception e) {
			throw e;
		}
	}

	@When("User sends amazon [username], [password] and click on login")
	public void whenUserSendsAmazonusernamepasswordAndClickOnLogin(@Named("username") String userName,
			@Named("password") String password) throws Throwable {
		try {
			reUse.sendKeys("amazonUsernameField", userName);
			reUse.click("continue");
			reUse.sendKeys("amazonPasswordField", password);
			reUse.click("amazonSignInSubmit");
		} catch (Exception e) {
			throw e;
		}
	}

	@When("User sends amazon invalid [username] and click on continue")
	public void whenUserSendsAmazonInvalidusernameAndClickOnContinue(@Named("username") String username)
			throws Throwable {
		try {
			reUse.sendKeys("amazonUsernameField", username);
			reUse.click("continue");
		} catch (Exception e) {
			throw e;
		}
	}

	@Then("User should validate whether amazon login is successful")
	public void thenUserShouldValidateWhetherAmazonLoginIsSuccessful() throws Throwable {
		try {
			reUse.elementExists("HelloSuresh");
			driver.quit();
		} catch (Exception e) {
			throw e;
		}
	}

	@Then("User should validate whether amazon login is failed")
	public void thenUserShouldValidateWhetherAmazonLoginIsFailed() throws Throwable {
		try {
			reUse.elementExists("amazonInvalidLoginMessagePath");
			driver.quit();
		} catch (Exception e) {
			throw e;
		}
	}
}
