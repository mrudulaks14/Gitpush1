package com.test.jbehave.steps;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.test.jbehave.utils.DriverDefinitions;
import com.test.jbehave.utils.ReusableMethods;

public class InsightsClass {

	WebDriver driver = null;
	WebDriverWait oWait = null;
	ReusableMethods reUse = null;

	public InsightsClass() throws Exception {
		try {
			driver = DriverDefinitions.getDriver();
			reUse = new ReusableMethods();

		} catch (Exception e) {
			throw e;
		}
	}

	@Given("User is provided with insights URL")
	public void givenUserIsProvidedWithInsightsURL() throws IOException {
		driver.get(reUse.getProperty("insightsUrl"));
	}

	@When("User login to the system")
	public void whenUserLoginToTheSystem() throws Exception {
		Robot robo = new Robot();

		reUse.robotKeyPress(reUse.decryptText("iUN"));
		robo.keyPress(KeyEvent.VK_TAB);
		reUse.robotKeyPress(reUse.decryptText("iPW"));
		robo.keyPress(KeyEvent.VK_ENTER);
	}

	@Then("User should validate the profile name")
	public void thenUserShouldValidateTheProfileName() throws Exception {
		Assert.assertTrue(reUse.getElementText("profileNameXpath").equalsIgnoreCase(reUse.getProperty("profileName")));
		driver.quit();
	}
}