package com.test.jbehave.steps;

import java.io.IOException;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.test.jbehave.utils.DriverDefinitions;
import com.test.jbehave.utils.ReusableMethods;

public class CourseClass {

	WebDriver driver = null;
	WebDriverWait oWait = null;
	ReusableMethods reUse = null;

	public CourseClass() throws Exception {
		try {
			driver = DriverDefinitions.getDriver();
			reUse = new ReusableMethods();
		} catch (Exception e) {
			throw e;
		}
	}

	@Given("User is provided with c learn URL")
	public void givenUserIsProvidedWithCLearnURL() throws IOException {
		driver.get(reUse.getProperty("cLearnURL"));
	}

	@When("User logins to the system and select a particular course by filtering")
	public void whenUserLoginsToTheSystemAndSelectAParticularCourseByFiltering() throws IOException, Exception {
		reUse.sendKeysProp("cUserName", "cUN");
		reUse.sendKeysProp("cPassword", "cPW");
		reUse.click("loginBtn");
		reUse.click("accept");
		reUse.click("mainSearchIcon");
		reUse.sendKeys("searchBox", reUse.getProperty("searchText"));
		reUse.click("textSearchIcon");
		reUse.click("course");
	}

	@Then("User should validate the selected course")
	public void thenUserShouldValidateTheSelectedCourse() throws Exception {
		reUse.switchToFrame("frameXpath");
		String[] elementText = reUse.getElementText("coursetitleXpath").split("\\R");
		Assert.assertTrue(elementText[0].concat(elementText[1]).equalsIgnoreCase(reUse.getProperty("CourseTitle")));
		driver.switchTo().defaultContent();
		driver.quit();
	}
}