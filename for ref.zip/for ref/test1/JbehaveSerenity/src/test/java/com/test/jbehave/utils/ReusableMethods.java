package com.test.jbehave.utils;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReusableMethods {

	WebDriver driver = null;
	WebDriverWait oWait = null;
	Actions action = null;
	Properties propObj = null;
	EncryptionDecryption decryption = null;

	public ReusableMethods() throws Exception {
		try {
			this.driver = DriverDefinitions.getDriver();
			this.oWait = DriverDefinitions.getoWait();
			action = new Actions(this.driver);
			propObj = DriverDefinitions.getPropObj();
			decryption = new EncryptionDecryption();
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * Clicks on the element
	 * 
	 * @param xpath = Xpath variable name from property file
	 * @throws Exception
	 */
	public void click(String xpath) throws Exception {
		try {
			oWait.until(ExpectedConditions.elementToBeClickable(By.xpath(getProperty(xpath))));
			driver.findElement(By.xpath(getProperty(xpath))).click();

		} catch (AssertionError | IOException | TimeoutException | NoSuchElementException e) {
			throw e;
		}
	}

	/**
	 * Finds element and enteres the direct text provided
	 * 
	 * @param xpath = Xpath variable name from property file
	 * @param value = Direct String value to be entered
	 * @throws Exception
	 */
	public void sendKeys(String xpath, String value) throws Exception {
		try {
			oWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getProperty(xpath))));
			driver.findElement(By.xpath(getProperty(xpath))).sendKeys(value);

		} catch (AssertionError | IOException | TimeoutException | NoSuchElementException e) {
			throw e;
		}
	}

	/**
	 * Finds element and gets the value from property file and enters
	 * 
	 * @param xpath = Xpath variable name from property file
	 * @param value = Value variable name from property file
	 * @throws Exception
	 */
	public void sendKeysProp(String xpath, String value) throws Exception {
		try {
			oWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getProperty(xpath))));
			driver.findElement(By.xpath(getProperty(xpath))).sendKeys(decryptText(value));

		} catch (AssertionError | IOException | TimeoutException | NoSuchElementException e) {
			throw e;
		}
	}

	/**
	 * Gets window title & validates with given title for contains condition
	 * 
	 * @param title = Expected title variable from property file to validate
	 * @throws Throwable
	 */
	public void assertTitleContains(String title) throws Throwable {

		try {
			assertTrue(driver.getTitle().contains(getProperty(title)));

		} catch (AssertionError | IOException e) {
			throw e;
		}
	}

	/**
	 * Gets window title & validates with given title for equals to condition
	 * 
	 * @param title = Expected title variable from property file to validate
	 * @throws Throwable
	 */
	public void assertTitleEquals(String title) throws Throwable {
		try {
			assertTrue(driver.getTitle().equals(getProperty(title)));

		} catch (AssertionError | IOException e) {
			throw e;
		}
	}

	/**
	 * Mouse over action to locate a particular element
	 * 
	 * @param xpath = Element xpath variable name from property file
	 * @throws Exception
	 */
	public void moveOnTo(String xpath) throws Exception {
		try {
			oWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getProperty(xpath))));
			WebElement element = driver.findElement(By.xpath(getProperty(xpath)));
			action.moveToElement(element).perform();

		} catch (AssertionError | IOException | TimeoutException | NoSuchElementException e) {
			throw e;
		}
	}

	/**
	 * Mouse over to locate an element & also clicks on the element
	 * 
	 * @param xpath = Element xpath variable name from property file
	 * @throws Exception
	 */
	public void moveAndClick(String xpath) throws Exception {
		try {
			oWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getProperty(xpath))));
			WebElement element = driver.findElement(By.xpath(getProperty(xpath)));
			action.moveToElement(element).click().perform();

		} catch (AssertionError | IOException | TimeoutException | NoSuchElementException e) {
			throw e;
		}
	}

	/**
	 * Validates whether there exists an element with given xpath
	 * 
	 * @param xpath = Element xpath variable name from property file
	 * @throws Exception
	 */
	public void elementExists(String xpath) throws Exception {
		try {
			oWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getProperty(xpath))));
			WebElement element = driver.findElement(By.xpath(getProperty(xpath)));
			assertTrue(element.isDisplayed());

		} catch (AssertionError | IOException | TimeoutException | NoSuchElementException e) {
			throw e;
		}
	}

	/**
	 * Gets and returns element text
	 * 
	 * @param xpath = Element xpath variable name from property file
	 * @return = Element text of given xpath
	 * @throws Exception
	 */
	public String getElementText(String xpath) throws Exception {
		String text = null;
		try {
			oWait.until(ExpectedConditions.elementToBeClickable(By.xpath(getProperty(xpath))));
			text = driver.findElement(By.xpath(getProperty(xpath))).getText();

		} catch (AssertionError | IOException | TimeoutException | NoSuchElementException e) {
			throw e;
		}
		return text;
	}

	/**
	 * Decrypts the given string and returns the result
	 * 
	 * @param key = String variable name from property file to decrypt
	 * @return
	 */
	public String decryptText(String key) {
		String decryptedText = null;
		try {
			decryptedText = decryption.decrypt(getProperty(key));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return decryptedText;

	}

	/**
	 * Switches into frame
	 * 
	 * @param xpath = frame xpath variable name from property file
	 * @throws Exception
	 */
	public void switchToFrame(String xpath) throws Exception {
		try {
			oWait.until(ExpectedConditions.elementToBeClickable(By.xpath(getProperty(xpath))));
			driver.switchTo().frame(driver.findElement(By.xpath(getProperty(xpath))));

		} catch (AssertionError | IOException | TimeoutException | NoSuchElementException e) {
			throw e;
		}
	}

	/**
	 * Robot- Splits given string and performs each key press action
	 * 
	 * @param text = String to be keyed in
	 * @throws Exception
	 */
	public void robotKeyPress(String text) throws Exception {
		try {
			Robot robo = new Robot();
			Thread.sleep(2000);
			String[] keys = text.split("(?!^)");

			for (String key : keys) {

				if (key.equals("0"))
					robo.keyPress(KeyEvent.VK_0);
				else if (key.equals("1"))
					robo.keyPress(KeyEvent.VK_1);
				else if (key.equals("2"))
					robo.keyPress(KeyEvent.VK_2);
				else if (key.equals("3"))
					robo.keyPress(KeyEvent.VK_3);
				else if (key.equals("4"))
					robo.keyPress(KeyEvent.VK_4);
				else if (key.equals("5"))
					robo.keyPress(KeyEvent.VK_5);
				else if (key.equals("6"))
					robo.keyPress(KeyEvent.VK_6);
				else if (key.equals("7"))
					robo.keyPress(KeyEvent.VK_7);
				else if (key.equals("8"))
					robo.keyPress(KeyEvent.VK_8);
				else if (key.equals("9"))
					robo.keyPress(KeyEvent.VK_9);
				else if (key.equals("a"))
					robo.keyPress(KeyEvent.VK_A);
				else if (key.equals("s"))
					robo.keyPress(KeyEvent.VK_S);
				else if (key.equals("S")) {
					robo.keyPress(KeyEvent.VK_SHIFT);
					robo.keyPress(KeyEvent.VK_S);
					robo.keyRelease(KeyEvent.VK_SHIFT);
				} else if (key.equals("u"))
					robo.keyPress(KeyEvent.VK_U);
				else if (key.equals("r"))
					robo.keyPress(KeyEvent.VK_R);
				else if (key.equals("e"))
					robo.keyPress(KeyEvent.VK_E);
				else if (key.equals("h"))
					robo.keyPress(KeyEvent.VK_H);
				else if (key.equals("."))
					robo.keyPress(KeyEvent.VK_PERIOD);
				else if (key.equals("@")) {
					robo.keyPress(KeyEvent.VK_SHIFT);
					robo.keyPress(KeyEvent.VK_2);
					robo.keyRelease(KeyEvent.VK_SHIFT);
				} else if (key.equals("d"))
					robo.keyPress(KeyEvent.VK_D);
				else if (key.equals("l"))
					robo.keyPress(KeyEvent.VK_L);
				else if (key.equals("v"))
					robo.keyPress(KeyEvent.VK_V);
				else if (key.equals("y"))
					robo.keyPress(KeyEvent.VK_Y);
				else if (key.equals("i"))
					robo.keyPress(KeyEvent.VK_I);

			}
			Thread.sleep(2000);
		} catch (AWTException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Gets the property values from the config value and returns it
	 * 
	 * @param key = Variable name from property file
	 * @return = Returns variable name's equivalent value
	 * @throws IOException
	 */
	public String getProperty(String key) throws IOException {
		String propertyValue = null;
		try {
			propertyValue = propObj.getProperty(key).toString();
		} catch (Exception e) {
			throw e;
		}
		return propertyValue;
	}

}
