package com.test.jbehave.utils;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.annotations.BeforeScenario;
import org.jbehave.core.annotations.ScenarioType;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DriverDefinitions {

	private static WebDriver driver = null;
	private static WebDriverWait oWait = null;
	private static Properties propObj = new Properties();
	private static String browser = null;

	public static String getBrowser() {
		return browser;
	}

	public static Properties getPropObj() {
		return propObj;
	}

	public static WebDriver getDriver() {
		return driver;
	}

	public static WebDriverWait getoWait() {
		return oWait;
	}

	public static void setDriverDefinitions() throws IOException {
		try {

			FileInputStream objfile = new FileInputStream(
					System.getProperty("user.dir") + "/src/main/resources/config.properties");
			propObj.load(objfile);
			browser = propObj.getProperty("browserName");

			switch (browser.toString().toLowerCase()) {
			case "chrome":
				System.setProperty("webdriver.chrome.driver", "./src/test/resources/Drivers/chromedriver.exe");
				driver = new ChromeDriver();
				break;

			case "firefox":
				System.setProperty("webdriver.gecko.driver", "./src/test/resources/Drivers/geckodriver.exe");
				driver = new FirefoxDriver();
				break;

			default:
				System.out.println("Invalid Browser name in config.properties file");
				assertEquals(true, false);
			}

			driver.manage().window().maximize();
			oWait = new WebDriverWait(driver, 20);

		} catch (Exception e) {
			throw e;
		}

	}

	@BeforeScenario(uponType = ScenarioType.ANY)
	public void AmazonDriverSetup() throws Throwable {
		try {
			DriverDefinitions.setDriverDefinitions();
		} catch (Exception e) {
			throw e;
		}
	}

	@AfterScenario(uponType = ScenarioType.ANY)
	public void AfterScenarioQuit() throws Exception {

		if (driver == null || driver.toString().contains("(null)")) {
			return;
		} else {
			try {
				File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				String fileName = "./target/site/" + System.currentTimeMillis() + ".png";
				FileUtils.copyFile(src, new File(fileName));
				System.out.println("For more details on this failure refer screenshot : "+fileName);
				driver.quit();

			} catch (Exception e) {
				throw e;
			}
		}
	}
}
