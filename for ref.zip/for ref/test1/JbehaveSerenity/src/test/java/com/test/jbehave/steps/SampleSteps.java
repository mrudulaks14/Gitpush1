package com.test.jbehave.steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.openqa.selenium.WebDriver;

import com.test.jbehave.utils.DriverDefinitions;

public class SampleSteps {

	WebDriver driver=null;
	
	public SampleSteps() {
		driver=DriverDefinitions.getDriver();
		
	}
    @Given("my foo method ...")
    public void foo() {
        System.out.println("[Given] my foo method ...");
    }

    @Then("my bar method ...")
    public void bar() {
        System.out.println("[Then] my bar method ...");
        driver.quit();
    }
    
}