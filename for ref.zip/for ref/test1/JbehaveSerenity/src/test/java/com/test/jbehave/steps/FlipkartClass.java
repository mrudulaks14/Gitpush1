package com.test.jbehave.steps;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.jbehave.utils.DriverDefinitions;
import com.test.jbehave.utils.ReusableMethods;

public class FlipkartClass {

	WebDriver driver = null;
	WebDriverWait oWait = null;
	ReusableMethods reUse = null;

	public FlipkartClass() throws Exception {
		try {
			driver = DriverDefinitions.getDriver();
			reUse = new ReusableMethods();
		} catch (Exception e) {
			throw e;
		}
	}

	@Given("User is provided with flipkart URL")
	public void givenUserIsProvidedWithFlipkartURL() throws IOException {
		driver.get(reUse.getProperty("flipkartURL"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("User login to the flipkart")
	public void whenUserLoginToTheFlipkart() throws Exception {
		reUse.sendKeysProp("fUserName", "fUN");
		reUse.sendKeysProp("fPassword", "fPW");
		reUse.click("floginBtn");

	}

	@Then("User should click on wishlist option")
	public void thenUserShouldClickOnWishlistOption() throws Exception {
		reUse.moveOnTo("account");
		reUse.moveAndClick("wishList");
		driver.quit();
	}
}