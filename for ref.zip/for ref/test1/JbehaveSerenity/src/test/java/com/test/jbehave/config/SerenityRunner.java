package com.test.jbehave.config;

import net.serenitybdd.jbehave.SerenityStories;
import java.util.Arrays;
import java.util.List;

public class SerenityRunner extends SerenityStories {	
	
	@Override
	public List<String> storyPaths() {
		return Arrays.asList(
				"stories/Requirement1.story"//,
			//	"stories/Requirement2.story",
			//	"stories/Requirement3.story"
				);
	}
}